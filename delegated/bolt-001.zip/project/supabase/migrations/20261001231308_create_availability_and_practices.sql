/*
# Create availability and proposed practices tables for dance team scheduling

## Overview
This migration creates two tables for the dance team practice scheduler:
1. `availability_entries` — stores times when team members are unavailable for practice
   (with an optional academic conflict reason).
2. `proposed_practices` — stores practice times proposed by team leadership.

The frontend compares proposed practices against availability entries to detect
overlapping conflicts (F-07 Practice Conflict Detection).

## New Tables

### availability_entries
- `id` (uuid, primary key)
- `member_name` (text, not null) — name of the team member submitting availability
- `date` (date, not null) — the date of unavailability
- `start_time` (time, not null) — start of the unavailable period
- `end_time` (time, not null) — end of the unavailable period
- `reason` (text, nullable) — optional academic conflict or reason description
- `created_at` (timestamptz, default now())

### proposed_practices
- `id` (uuid, primary key)
- `date` (date, not null) — the proposed practice date
- `start_time` (time, not null) — expected practice start time
- `end_time` (time, not null) — expected practice end time
- `location` (text, nullable) — optional practice location
- `notes` (text, nullable) — optional notes from leadership
- `status` (text, not null, default 'proposed') — proposed | finalized
- `created_at` (timestamptz, default now())

## Security
- RLS enabled on both tables.
- No authentication in this app (single-tenant, shared scheduling tool).
- Policies allow anon + authenticated to perform full CRUD on both tables,
  because the data is intentionally shared/public among team members and leadership.
*/

CREATE TABLE IF NOT EXISTS availability_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  member_name text NOT NULL,
  date date NOT NULL,
  start_time time NOT NULL,
  end_time time NOT NULL,
  reason text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE availability_entries ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_availability_entries" ON availability_entries;
CREATE POLICY "anon_select_availability_entries"
  ON availability_entries FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_availability_entries" ON availability_entries;
CREATE POLICY "anon_insert_availability_entries"
  ON availability_entries FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_availability_entries" ON availability_entries;
CREATE POLICY "anon_update_availability_entries"
  ON availability_entries FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_availability_entries" ON availability_entries;
CREATE POLICY "anon_delete_availability_entries"
  ON availability_entries FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS proposed_practices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL,
  start_time time NOT NULL,
  end_time time NOT NULL,
  location text,
  notes text,
  status text NOT NULL DEFAULT 'proposed',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE proposed_practices ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_proposed_practices" ON proposed_practices;
CREATE POLICY "anon_select_proposed_practices"
  ON proposed_practices FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_proposed_practices" ON proposed_practices;
CREATE POLICY "anon_insert_proposed_practices"
  ON proposed_practices FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_proposed_practices" ON proposed_practices;
CREATE POLICY "anon_update_proposed_practices"
  ON proposed_practices FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_proposed_practices" ON proposed_practices;
CREATE POLICY "anon_delete_proposed_practices"
  ON proposed_practices FOR DELETE
  TO anon, authenticated USING (true);
