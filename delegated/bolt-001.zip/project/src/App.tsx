import { useState } from 'react';
import { AvailabilityPanel } from '@/components/AvailabilityPanel';
import { PracticePanel } from '@/components/PracticePanel';
import { CalendarX, CalendarCheck, Users, Dumbbell } from 'lucide-react';

type Tab = 'availability' | 'practice';

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('practice');
  const [availabilityVersion, setAvailabilityVersion] = useState(0);

  const handleEntriesChange = () => {
    setAvailabilityVersion((v) => v + 1);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-3xl px-4 py-5 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-900 text-white">
              <Dumbbell className="h-5 w-5" />
            </div>
            <div>
              <h1 className="text-lg font-semibold text-slate-900">Dance Team Scheduler</h1>
              <p className="text-sm text-slate-500">Practice conflict detection for competitive dance teams</p>
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4 py-8 sm:px-6">
        {/* Tab navigation */}
        <div className="mb-6 flex gap-1 rounded-lg border border-slate-200 bg-white p-1">
          <button
            onClick={() => setActiveTab('practice')}
            className={`flex flex-1 items-center justify-center gap-2 rounded-md px-4 py-2.5 text-sm font-medium transition-colors ${
              activeTab === 'practice'
                ? 'bg-slate-900 text-white'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <CalendarCheck className="h-4 w-4" />
            Proposed Practices
          </button>
          <button
            onClick={() => setActiveTab('availability')}
            className={`flex flex-1 items-center justify-center gap-2 rounded-md px-4 py-2.5 text-sm font-medium transition-colors ${
              activeTab === 'availability'
                ? 'bg-slate-900 text-white'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <CalendarX className="h-4 w-4" />
            Member Availability
          </button>
        </div>

        {/* Content */}
        {activeTab === 'practice' ? (
          <PracticePanel availabilityVersion={availabilityVersion} />
        ) : (
          <AvailabilityPanel onEntriesChange={handleEntriesChange} />
        )}

        {/* Info banner */}
        <div className="mt-8 rounded-lg border border-slate-200 bg-white p-5">
          <h2 className="flex items-center gap-2 text-sm font-semibold text-slate-700">
            <Users className="h-4 w-4 text-slate-500" />
            How it works
          </h2>
          <ol className="mt-3 space-y-2 text-sm text-slate-600">
            <li className="flex gap-2">
              <span className="font-semibold text-slate-400">1.</span>
              <span>Team members submit times they are unavailable for practice, with optional academic conflict reasons.</span>
            </li>
            <li className="flex gap-2">
              <span className="font-semibold text-slate-400">2.</span>
              <span>Team leadership proposes a practice with a date, start time, and expected end time.</span>
            </li>
            <li className="flex gap-2">
              <span className="font-semibold text-slate-400">3.</span>
              <span>The system compares the proposed practice against all submitted availability and identifies any overlapping conflicts for leadership to review.</span>
            </li>
            <li className="flex gap-2">
              <span className="font-semibold text-slate-400">4.</span>
              <span>Leadership decides whether to adjust the practice or keep the proposed time — the system does not automatically prioritize one commitment over another.</span>
            </li>
          </ol>
        </div>
      </main>

      <footer className="border-t border-slate-200 bg-white">
        <div className="mx-auto max-w-3xl px-4 py-4 text-center text-xs text-slate-400 sm:px-6">
          Dance Team Scheduler · Practice conflict detection
        </div>
      </footer>
    </div>
  );
}

export default App;
