import type { AvailabilityEntry, ConflictResult } from './types';

/**
 * Convert "HH:MM" time string to minutes since midnight for comparison.
 */
function timeToMinutes(time: string): number {
  const [hours, minutes] = time.split(':').map(Number);
  return hours * 60 + minutes;
}

/**
 * Detect conflicts between a proposed practice and a list of availability entries.
 * A conflict exists when the practice date matches and the time ranges overlap.
 * Two ranges [aStart, aEnd) and [bStart, bEnd) overlap when aStart < bEnd and bStart < aEnd.
 */
export function detectConflicts(
  practice: { date: string; start_time: string; end_time: string },
  entries: AvailabilityEntry[]
): ConflictResult[] {
  const practiceStart = timeToMinutes(practice.start_time);
  const practiceEnd = timeToMinutes(practice.end_time);

  return entries
    .filter((entry) => entry.date === practice.date)
    .filter((entry) => {
      const entryStart = timeToMinutes(entry.start_time);
      const entryEnd = timeToMinutes(entry.end_time);
      return entryStart < practiceEnd && practiceStart < entryEnd;
    })
    .map((entry) => {
      const entryStart = timeToMinutes(entry.start_time);
      const entryEnd = timeToMinutes(entry.end_time);
      const overlapStart = Math.max(practiceStart, entryStart);
      const overlapEnd = Math.min(practiceEnd, entryEnd);
      return {
        entry,
        overlapStart: minutesToTime(overlapStart),
        overlapEnd: minutesToTime(overlapEnd),
      };
    });
}

function minutesToTime(minutes: number): string {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}`;
}

/**
 * Format a time string "HH:MM" into 12-hour format "h:MM AM/PM".
 */
export function formatTime(time: string): string {
  const [hours, minutes] = time.split(':').map(Number);
  const period = hours >= 12 ? 'PM' : 'AM';
  const displayHours = hours === 0 ? 12 : hours > 12 ? hours - 12 : hours;
  return `${displayHours}:${String(minutes).padStart(2, '0')} ${period}`;
}

/**
 * Format an ISO date string "YYYY-MM-DD" into a readable format.
 */
export function formatDate(dateStr: string): string {
  const date = new Date(dateStr + 'T00:00:00');
  return date.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}
