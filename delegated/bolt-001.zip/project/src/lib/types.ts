export interface AvailabilityEntry {
  id: string;
  member_name: string;
  date: string;
  start_time: string;
  end_time: string;
  reason: string | null;
  created_at: string;
}

export interface ProposedPractice {
  id: string;
  date: string;
  start_time: string;
  end_time: string;
  location: string | null;
  notes: string | null;
  status: 'proposed' | 'finalized';
  created_at: string;
}

export interface ConflictResult {
  entry: AvailabilityEntry;
  overlapStart: string;
  overlapEnd: string;
}
