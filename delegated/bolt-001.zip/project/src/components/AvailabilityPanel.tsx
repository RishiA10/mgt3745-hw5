import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import type { AvailabilityEntry } from '@/lib/types';
import { formatDate, formatTime } from '@/lib/conflictDetection';
import { Calendar, Clock, Trash2, AlertCircle, Plus, User } from 'lucide-react';

interface AvailabilityFormProps {
  onEntriesChange: () => void;
}

export function AvailabilityPanel({ onEntriesChange }: AvailabilityFormProps) {
  const [entries, setEntries] = useState<AvailabilityEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [saveError, setSaveError] = useState('');
  const [saveSuccess, setSaveSuccess] = useState('');

  // Form fields — preserved on failed write per STANDARDS.md rule 3
  const [memberName, setMemberName] = useState('');
  const [date, setDate] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [reason, setReason] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const loadEntries = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const { data, error: queryError } = await supabase
        .from('availability_entries')
        .select('*')
        .order('date', { ascending: true })
        .order('start_time', { ascending: true });

      if (queryError) throw queryError;
      setEntries(data ?? []);
    } catch {
      setError('Could not load availability entries. Please try again.');
      setEntries([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadEntries();
  }, [loadEntries]);

  const refreshParent = useCallback(() => {
    onEntriesChange();
  }, [onEntriesChange]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaveError('');
    setSaveSuccess('');

    if (!memberName.trim()) {
      setSaveError('Please enter your name.');
      return;
    }
    if (!date || !startTime || !endTime) {
      setSaveError('Date, start time, and end time are required.');
      return;
    }
    if (endTime <= startTime) {
      setSaveError('End time must be later than start time.');
      return;
    }

    setSubmitting(true);
    try {
      const { error: insertError } = await supabase
        .from('availability_entries')
        .insert({
          member_name: memberName.trim(),
          date,
          start_time: startTime,
          end_time: endTime,
          reason: reason.trim() || null,
        });

      if (insertError) throw insertError;

      setSaveSuccess('Availability saved successfully.');
      setReason('');
      setEndTime('');
      setStartTime('');
      setDate('');
      await loadEntries();
      refreshParent();
    } catch {
      // Preserve unsaved form input so the user does not have to re-enter
      setSaveError('Could not save. Your information is still here. Try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const { error: deleteError } = await supabase
        .from('availability_entries')
        .delete()
        .eq('id', id);

      if (deleteError) throw deleteError;
      await loadEntries();
      refreshParent();
    } catch {
      setError('Could not delete entry. Please try again.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="rounded-lg border border-slate-200 bg-white p-6 shadow-sm">
        <h2 className="flex items-center gap-2 text-xl font-semibold text-slate-900">
          <Plus className="h-5 w-5 text-slate-600" />
          Submit Unavailable Time
        </h2>
        <p className="mt-1 text-sm text-slate-500">
          Enter times when you are unavailable for practice, along with an optional academic conflict reason.
        </p>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4" noValidate>
          <div>
            <label htmlFor="member-name" className="flex items-center gap-1.5 text-sm font-medium text-slate-700">
              <User className="h-4 w-4" />
              Member name
            </label>
            <input
              id="member-name"
              type="text"
              value={memberName}
              onChange={(e) => setMemberName(e.target.value)}
              maxLength={100}
              autoComplete="off"
              className="mt-1.5 w-full rounded-md border border-slate-300 px-3 py-2 text-slate-900 placeholder-slate-400 focus:border-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-200"
              placeholder="e.g., Alex Chen"
            />
          </div>

          <div>
            <label htmlFor="avail-date" className="flex items-center gap-1.5 text-sm font-medium text-slate-700">
              <Calendar className="h-4 w-4" />
              Date
            </label>
            <input
              id="avail-date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="mt-1.5 w-full rounded-md border border-slate-300 px-3 py-2 text-slate-900 focus:border-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-200"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="avail-start" className="flex items-center gap-1.5 text-sm font-medium text-slate-700">
                <Clock className="h-4 w-4" />
                Start time
              </label>
              <input
                id="avail-start"
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className="mt-1.5 w-full rounded-md border border-slate-300 px-3 py-2 text-slate-900 focus:border-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-200"
              />
            </div>
            <div>
              <label htmlFor="avail-end" className="flex items-center gap-1.5 text-sm font-medium text-slate-700">
                <Clock className="h-4 w-4" />
                End time
              </label>
              <input
                id="avail-end"
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                className="mt-1.5 w-full rounded-md border border-slate-300 px-3 py-2 text-slate-900 focus:border-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-200"
              />
            </div>
          </div>

          <div>
            <label htmlFor="avail-reason" className="text-sm font-medium text-slate-700">
              Academic conflict or reason <span className="font-normal text-slate-400">(optional)</span>
            </label>
            <input
              id="avail-reason"
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              maxLength={200}
              autoComplete="off"
              className="mt-1.5 w-full rounded-md border border-slate-300 px-3 py-2 text-slate-900 placeholder-slate-400 focus:border-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-200"
              placeholder="e.g., Exam, MCAT prep, interview"
            />
          </div>

          {saveError && (
            <p role="alert" className="flex items-center gap-2 rounded-md bg-red-50 px-3 py-2 text-sm text-red-700">
              <AlertCircle className="h-4 w-4 shrink-0" />
              {saveError}
            </p>
          )}
          {saveSuccess && (
            <p role="status" className="rounded-md bg-green-50 px-3 py-2 text-sm text-green-700">
              {saveSuccess}
            </p>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="inline-flex items-center justify-center gap-2 rounded-md bg-slate-900 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-300 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Plus className="h-4 w-4" />
            {submitting ? 'Saving…' : 'Add Availability'}
          </button>
        </form>
      </div>

      <div className="rounded-lg border border-slate-200 bg-white p-6 shadow-sm">
        <h2 className="text-xl font-semibold text-slate-900">Submitted Availability</h2>
        {error && (
          <p role="alert" className="mt-3 flex items-center gap-2 rounded-md bg-red-50 px-3 py-2 text-sm text-red-700">
            <AlertCircle className="h-4 w-4 shrink-0" />
            {error}
          </p>
        )}
        {loading ? (
          <p className="mt-4 text-sm text-slate-500">Loading entries…</p>
        ) : entries.length === 0 ? (
          <p className="mt-4 text-sm text-slate-500">No availability submitted yet.</p>
        ) : (
          <ul className="mt-4 divide-y divide-slate-100">
            {entries.map((entry) => (
              <li key={entry.id} className="flex items-start justify-between gap-4 py-3">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-slate-900">{entry.member_name}</p>
                  <p className="mt-0.5 text-sm text-slate-600">
                    {formatDate(entry.date)} · {formatTime(entry.start_time)} – {formatTime(entry.end_time)}
                  </p>
                  {entry.reason && (
                    <p className="mt-1 text-sm text-slate-500">{entry.reason}</p>
                  )}
                </div>
                <button
                  onClick={() => handleDelete(entry.id)}
                  className="shrink-0 rounded-md p-2 text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600 focus:outline-none focus:ring-2 focus:ring-red-200"
                  aria-label={`Delete availability entry for ${entry.member_name}`}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
