import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import type { AvailabilityEntry, ProposedPractice, ConflictResult } from '@/lib/types';
import { detectConflicts, formatDate, formatTime } from '@/lib/conflictDetection';
import {
  Calendar,
  Clock,
  MapPin,
  AlertTriangle,
  CheckCircle2,
  Trash2,
  ClipboardList,
  Send,
} from 'lucide-react';

interface PracticePanelProps {
  availabilityVersion: number;
}

export function PracticePanel({ availabilityVersion }: PracticePanelProps) {
  const [practices, setPractices] = useState<ProposedPractice[]>([]);
  const [availability, setAvailability] = useState<AvailabilityEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [saveError, setSaveError] = useState('');
  const [saveSuccess, setSaveSuccess] = useState('');
  const [conflictResults, setConflictResults] = useState<ConflictResult[]>([]);
  const [checkedPracticeId, setCheckedPracticeId] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Form fields — preserved on failed write per STANDARDS.md rule 3
  const [date, setDate] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [location, setLocation] = useState('');
  const [notes, setNotes] = useState('');

  const loadPractices = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const { data, error: queryError } = await supabase
        .from('proposed_practices')
        .select('*')
        .order('date', { ascending: true })
        .order('start_time', { ascending: true });

      if (queryError) throw queryError;
      setPractices(data ?? []);
    } catch {
      setError('Could not load proposed practices. Please try again.');
      setPractices([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const loadAvailability = useCallback(async () => {
    try {
      const { data, error: queryError } = await supabase
        .from('availability_entries')
        .select('*')
        .order('date', { ascending: true });

      if (queryError) throw queryError;
      setAvailability(data ?? []);
    } catch {
      // Non-fatal: conflict detection will just report no conflicts
      setAvailability([]);
    }
  }, []);

  useEffect(() => {
    loadPractices();
  }, [loadPractices]);

  // Reload availability whenever the parent signals a change
  useEffect(() => {
    loadAvailability();
  }, [availabilityVersion, loadAvailability]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaveError('');
    setSaveSuccess('');
    setConflictResults([]);
    setCheckedPracticeId(null);

    // Validation: missing required fields
    if (!date || !startTime || !endTime) {
      setSaveError('Date, start time, and end time are required.');
      return;
    }

    // Validation: end time must be after start time
    if (endTime <= startTime) {
      setSaveError('End time must be after the start time.');
      return;
    }

    setSubmitting(true);
    try {
      const { data, error: insertError } = await supabase
        .from('proposed_practices')
        .insert({
          date,
          start_time: startTime,
          end_time: endTime,
          location: location.trim() || null,
          notes: notes.trim() || null,
        })
        .select()
        .single();

      if (insertError) throw insertError;

      // Immediately run conflict detection on the new practice (F-07)
      const conflicts = detectConflicts(data, availability);
      setConflictResults(conflicts);
      setCheckedPracticeId(data.id);

      if (conflicts.length > 0) {
        setSaveSuccess(`Practice saved — ${conflicts.length} conflict${conflicts.length > 1 ? 's' : ''} detected.`);
      } else {
        setSaveSuccess('Practice saved — no availability conflicts found.');
      }

      setLocation('');
      setNotes('');
      setEndTime('');
      setStartTime('');
      setDate('');
      await loadPractices();
    } catch {
      // Preserve unsaved form input so the user does not have to re-enter
      setSaveError('Could not save. Your information is still here. Try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCheckConflicts = (practice: ProposedPractice) => {
    const conflicts = detectConflicts(practice, availability);
    setConflictResults(conflicts);
    setCheckedPracticeId(practice.id);
    setSaveSuccess('');
    setSaveError('');
  };

  const handleDelete = async (id: string) => {
    try {
      const { error: deleteError } = await supabase
        .from('proposed_practices')
        .delete()
        .eq('id', id);

      if (deleteError) throw deleteError;
      if (checkedPracticeId === id) {
        setCheckedPracticeId(null);
        setConflictResults([]);
      }
      await loadPractices();
    } catch {
      setError('Could not delete practice. Please try again.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="rounded-lg border border-slate-200 bg-white p-6 shadow-sm">
        <h2 className="flex items-center gap-2 text-xl font-semibold text-slate-900">
          <ClipboardList className="h-5 w-5 text-slate-600" />
          Propose a Practice
        </h2>
        <p className="mt-1 text-sm text-slate-500">
          Submit a proposed practice time. The system will check it against all submitted member availability and report any conflicts.
        </p>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4" noValidate>
          <div>
            <label htmlFor="practice-date" className="flex items-center gap-1.5 text-sm font-medium text-slate-700">
              <Calendar className="h-4 w-4" />
              Date
            </label>
            <input
              id="practice-date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="mt-1.5 w-full rounded-md border border-slate-300 px-3 py-2 text-slate-900 focus:border-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-200"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="practice-start" className="flex items-center gap-1.5 text-sm font-medium text-slate-700">
                <Clock className="h-4 w-4" />
                Start time
              </label>
              <input
                id="practice-start"
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className="mt-1.5 w-full rounded-md border border-slate-300 px-3 py-2 text-slate-900 focus:border-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-200"
              />
            </div>
            <div>
              <label htmlFor="practice-end" className="flex items-center gap-1.5 text-sm font-medium text-slate-700">
                <Clock className="h-4 w-4" />
                End time
              </label>
              <input
                id="practice-end"
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                className="mt-1.5 w-full rounded-md border border-slate-300 px-3 py-2 text-slate-900 focus:border-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-200"
              />
            </div>
          </div>

          <div>
            <label htmlFor="practice-location" className="flex items-center gap-1.5 text-sm font-medium text-slate-700">
              <MapPin className="h-4 w-4" />
              Location <span className="font-normal text-slate-400">(optional)</span>
            </label>
            <input
              id="practice-location"
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              maxLength={200}
              autoComplete="off"
              className="mt-1.5 w-full rounded-md border border-slate-300 px-3 py-2 text-slate-900 placeholder-slate-400 focus:border-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-200"
              placeholder="e.g., Dance Studio B"
            />
          </div>

          <div>
            <label htmlFor="practice-notes" className="text-sm font-medium text-slate-700">
              Notes <span className="font-normal text-slate-400">(optional)</span>
            </label>
            <textarea
              id="practice-notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              maxLength={500}
              rows={2}
              className="mt-1.5 w-full rounded-md border border-slate-300 px-3 py-2 text-slate-900 placeholder-slate-400 focus:border-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-200"
              placeholder="e.g., Competition week — extra rehearsal time"
            />
          </div>

          {saveError && (
            <p role="alert" className="flex items-center gap-2 rounded-md bg-red-50 px-3 py-2 text-sm text-red-700">
              <AlertTriangle className="h-4 w-4 shrink-0" />
              {saveError}
            </p>
          )}
          {saveSuccess && (
            <p role="status" className="flex items-center gap-2 rounded-md bg-green-50 px-3 py-2 text-sm text-green-700">
              <CheckCircle2 className="h-4 w-4 shrink-0" />
              {saveSuccess}
            </p>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="inline-flex items-center justify-center gap-2 rounded-md bg-slate-900 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-300 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Send className="h-4 w-4" />
            {submitting ? 'Submitting…' : 'Submit Proposed Practice'}
          </button>
        </form>
      </div>

      {/* Conflict results panel */}
      {checkedPracticeId && (
        <div className={`rounded-lg border p-6 shadow-sm ${conflictResults.length > 0 ? 'border-amber-300 bg-amber-50' : 'border-green-300 bg-green-50'}`}>
          <h3 className={`flex items-center gap-2 text-lg font-semibold ${conflictResults.length > 0 ? 'text-amber-900' : 'text-green-900'}`}>
            {conflictResults.length > 0 ? (
              <AlertTriangle className="h-5 w-5" />
            ) : (
              <CheckCircle2 className="h-5 w-5" />
            )}
            {conflictResults.length > 0
              ? `${conflictResults.length} Conflict${conflictResults.length > 1 ? 's' : ''} Found`
              : 'No Availability Conflicts'}
          </h3>
          <p className={`mt-1 text-sm ${conflictResults.length > 0 ? 'text-amber-700' : 'text-green-700'}`}>
            {conflictResults.length > 0
              ? 'The proposed practice overlaps with the following member availability entries. Leadership should review these before finalizing.'
              : 'This proposed practice does not overlap with any submitted unavailable time.'}
          </p>
          {conflictResults.length > 0 && (
            <ul className="mt-4 divide-y divide-amber-200">
              {conflictResults.map((conflict) => (
                <li key={conflict.entry.id} className="py-3">
                  <p className="text-sm font-semibold text-amber-900">{conflict.entry.member_name}</p>
                  <p className="mt-0.5 text-sm text-amber-800">
                    Unavailable: {formatTime(conflict.entry.start_time)} – {formatTime(conflict.entry.end_time)}
                  </p>
                  <p className="mt-0.5 text-sm text-amber-700">
                    Overlapping period: {formatTime(conflict.overlapStart)} – {formatTime(conflict.overlapEnd)}
                  </p>
                  {conflict.entry.reason && (
                    <p className="mt-1 text-sm text-amber-600">Reason: {conflict.entry.reason}</p>
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      <div className="rounded-lg border border-slate-200 bg-white p-6 shadow-sm">
        <h2 className="text-xl font-semibold text-slate-900">Proposed Practices</h2>
        {error && (
          <p role="alert" className="mt-3 flex items-center gap-2 rounded-md bg-red-50 px-3 py-2 text-sm text-red-700">
            <AlertTriangle className="h-4 w-4 shrink-0" />
            {error}
          </p>
        )}
        {loading ? (
          <p className="mt-4 text-sm text-slate-500">Loading practices…</p>
        ) : practices.length === 0 ? (
          <p className="mt-4 text-sm text-slate-500">No practices proposed yet.</p>
        ) : (
          <ul className="mt-4 divide-y divide-slate-100">
            {practices.map((practice) => (
              <li key={practice.id} className="py-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-slate-900">
                      {formatDate(practice.date)}
                    </p>
                    <p className="mt-0.5 text-sm text-slate-600">
                      {formatTime(practice.start_time)} – {formatTime(practice.end_time)}
                    </p>
                    {practice.location && (
                      <p className="mt-1 flex items-center gap-1 text-sm text-slate-500">
                        <MapPin className="h-3.5 w-3.5" />
                        {practice.location}
                      </p>
                    )}
                    {practice.notes && (
                      <p className="mt-1 text-sm text-slate-500">{practice.notes}</p>
                    )}
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    <button
                      onClick={() => handleCheckConflicts(practice)}
                      className="inline-flex items-center gap-1.5 rounded-md border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-200"
                    >
                      <AlertTriangle className="h-3.5 w-3.5" />
                      Check conflicts
                    </button>
                    <button
                      onClick={() => handleDelete(practice.id)}
                      className="rounded-md p-2 text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600 focus:outline-none focus:ring-2 focus:ring-red-200"
                      aria-label="Delete proposed practice"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
